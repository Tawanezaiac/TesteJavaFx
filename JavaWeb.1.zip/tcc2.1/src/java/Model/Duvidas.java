/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;



public class Duvidas {
    private int id_duvida;
    private String email_duvida;
    private String nome_duvida;
    private int telefone_duvida;
    private String mensagem_duvida;
    
    public Duvidas(){
        
    }

    public Duvidas(int id_duvida, String email_duvida, String nome_duvida, int telefone_duvida, String mensagem_duvida) {
        this.email_duvida = email_duvida;
        this.id_duvida = id_duvida;
        this.nome_duvida = nome_duvida;
        this.telefone_duvida = telefone_duvida;
        this.mensagem_duvida = mensagem_duvida;
    }

    /**
     * @return the email_duvida
     */
    public String getEmail_duvida() {
        return email_duvida;
    }

    /**
     * @param email_duvida the email_duvida to set
     */
    public void setEmail_duvida(String email_duvida) {
        this.email_duvida = email_duvida;
    }

    /**
     * @return the nome_duvida
     */
    public String getNome_duvida() {
        return nome_duvida;
    }

    /**
     * @param nome_duvida the nome_duvida to set
     */
    public void setNome_duvida(String nome_duvida) {
        this.nome_duvida = nome_duvida;
    }

    /**
     * @return the telefone_duvida
     */
    public int getTelefone_duvida() {
        return telefone_duvida;
    }

    /**
     * @param telefone_duvida the telefone_duvida to set
     */
    public void setTelefone_duvida(int telefone_duvida) {
        this.telefone_duvida = telefone_duvida;
    }

    /**
     * @return the mensagem_duvida
     */
    public String getMensagem_duvida() {
        return mensagem_duvida;
    }

    /**
     * @param mensagem_duvida the mensagem_duvida to set
     */
    public void setMensagem_duvida(String mensagem_duvida) {
        this.mensagem_duvida = mensagem_duvida;
    }

    /**
     * @return the id_duvida
     */
    public int getId_duvida() {
        return id_duvida;
    }

    /**
     * @param id_duvida the id_duvida to set
     */
    public void setId_duvida(int id_duvida) {
        this.id_duvida = id_duvida;
    }
    
    
    
    
    
    
    
    
}
