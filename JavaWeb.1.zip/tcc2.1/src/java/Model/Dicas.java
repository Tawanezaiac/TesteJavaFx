
package Model;

import java.time.LocalDate;

public class Dicas {
    private int id_d;
    private String descricao_d;
    private String email_d;
    private LocalDate data_d;
    private String nome_d;

   public Dicas(){
       
   } 
   public Dicas (String descricao_d, String email_d,String nome_d, LocalDate data_d){
   this.descricao_d = descricao_d;
   this.email_d = email_d;
   this.data_d = data_d;
   this.nome_d = nome_d;
   }  
              @Override
    public String toString() {
        return "Dicas:"+"\n"+
                " descricao=" + descricao_d + "\n"+
                " email=" + email_d + "\n"+
                " nome=" + getNome_d() + "\n"+
                " data=" + data_d + "\n"+
                "\n";
    }

    /**
     * @return the id_d
     */
    public int getId_d() {
        return id_d;
    }

    /**
     * @param id_d the id_d to set
     */
    public void setId_d(int id_d) {
        this.id_d = id_d;
    }

    /**
     * @return the descricao_d
     */
    public String getDescricao_d() {
        return descricao_d;
    }

    /**
     * @param descricao_d the descricao_d to set
     */
    public void setDescricao_d(String descricao_d) {
        this.descricao_d = descricao_d;
    }

    /**
     * @return the email_d
     */
    public String getEmail_d() {
        return email_d;
    }

    /**
     * @param email_d the email_d to set
     */
    public void setEmail_d(String email_d) {
        this.email_d = email_d;
    }

    /**
     * @return the data_d
     */
    public LocalDate getData_d() {
        return data_d;
    }

    /**
     * @param data_d the data_d to set
     */
    public void setData_d(LocalDate data_d) {
        this.data_d = data_d;
    }

    /**
     * @return the nome_d
     */
    public String getNome_d() {
        return nome_d;
    }

    /**
     * @param nome_d the nome_d to set
     */
    public void setNome_d(String nome_d) {
        this.nome_d = nome_d;
    }
}
