
package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
public class CN {
private String caminho = "jdbc:postgresql://localhost/biopneu";
private String drive = "org.postgresql.Driver";
private String usuario = "postgres";
private String senha = "aluno";


public  static Connection getConnection(){
    try {
        Class.forName("org.postgresql.Driver");
          
    return DriverManager.getConnection("jdbc:postgresql://localhost/biopneu", "postgres", "aluno");
    } catch (Exception ex) {
           System.out.println(ex.getMessage());
        }  
        return null; 
        }
    }
    
//    public static Connection getConnection() throws ClassNotFoundException{
//        Connection u = null; 
//        try{
//            Class.forName("org.postgresql.Driver");
//            u = DriverManager.getConnection("jdbc:postgresql://localhost/biopneu", "postgres", "aluno"); 
//        } catch (SQLException ex){
//            System.out.println(ex.getMessage());
//        }catch(ClassNotFoundException e){
//            e.printStackTrace();
//       
//            }  
//        return u; 
//        }
    

