
package DAO;

import JDBC.CN;
import Model.Dicas;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;


public class DicasDAO {
     public static Connection c;
    public DicasDAO() throws ClassNotFoundException{
        DicasDAO.c = CN.getConnection();
    }
    
        @FXML public void InsereDicas(Dicas d){
      String sql = "INSERT INTO dicas" + "(email_d, nome_d, descricao_d)"
                    + "VALUES(?,?,?);";

               try {
                   PreparedStatement p = c.prepareStatement(sql);
                   p.setString(1, d.getEmail_d());
                   p.setString(2, d.getNome_d());
                   p.setString(3, d.getDescricao_d());
                   p.execute();
                   p.close();
        } catch (SQLException e) {
                   System.err.println("Erro ao Inserir DicasDAO" + e.getMessage());
        }
    }

    @FXML public ObservableList <Dicas> getDicas(){
        try {
            ObservableList <Dicas> f = FXCollections.observableArrayList(); 
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM dicas");
            ResultSet rs = stmt.executeQuery();
         while(rs.next()){
             Dicas p = new Dicas();
             p.setEmail_d(rs.getString("email_d"));
             p.setNome_d(rs.getString("nome_d"));
             p.setDescricao_d(rs.getString("descricao_d"));
//             Date dt = rs.getDate("data_d");
//             p.setData_d(dt.toLocalDate());   
             p.setId_d(rs.getInt("id_d"));
             f.add(p);
         }
         stmt.execute();
         rs.close();
         stmt.close();
         return f;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
       public void deletaDicas(Dicas di){
       String sql = "DELETE FROM dicas WHERE id_d  =?";
        try{
           PreparedStatement stmt = c.prepareStatement(sql);
           stmt.setInt(1, di.getId_d());
           stmt.execute();
           stmt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
        
   }
}

