
package DAO;
import JDBC.CN;
import Model.Pneu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
public class PneuDAO {
    public static Connection c;
    public PneuDAO() throws ClassNotFoundException{
        PneuDAO.c = CN.getConnection();
    }
    @FXML public void InserePneu(Pneu pn){
      String sql = "INSERT INTO pneu" + "(email_pn, bairro_pn, quantidade_pn, obs_pn, local_pn, data_pn)"
                    + "VALUES(?,?,?,?,?,?);";

               try {
                   PreparedStatement p = c.prepareStatement(sql);
                   p.setString(1, pn.getEmail_pn());
                   p.setString(2, pn.getBairro_pn());
                   p.setInt(3, pn.getQuantidade_pn());
                   p.setString(4, pn.getObs_pn());
                   p.setString(5, pn.getLocal_pn());
                   p.setDate(6, pn.getData_pn());
                   p.execute();
                   p.close();
        } catch (SQLException e) {
                   System.err.println("Erro ao Inserir PneuDAO" + e.getMessage());
        }
    }
    @FXML public ObservableList <Pneu> getPneu(){
        try {
            ObservableList <Pneu> f = FXCollections.observableArrayList(); 
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM pneu");
            ResultSet rs = stmt.executeQuery();
         while(rs.next()){
             Pneu p = new Pneu();
             p.setEmail_pn(rs.getString("email_pn"));
             p.setBairro_pn(rs.getString("bairro_pn"));
             p.setLocal_pn(rs.getString("local_pn"));
             p.setObs_pn(rs.getString("obs_pn"));
             p.setQuantidade_pn(rs.getInt("quantidade_pn"));
             p.setId_pn(rs.getInt("id_pn"));
             f.add(p);
         }
         stmt.execute();
         rs.close();
         stmt.close();
         return f;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
           public void deletaPneu(Pneu pne){
       String sql = "DELETE FROM pneu WHERE id_pn  =?";
        try{
           PreparedStatement stmt = c.prepareStatement(sql);
           stmt.setInt(1, pne.getId_pn());
           stmt.execute();
           stmt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
        
   }
}
