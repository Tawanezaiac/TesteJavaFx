/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static DAO.DicasDAO.c;
import JDBC.CN;
import Model.Dicas;
import Model.Duvidas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

/**
 *
 * @author User
 */
public class DuvidasDAO {
     public static Connection c;
    public DuvidasDAO() throws ClassNotFoundException{
        DuvidasDAO.c = CN.getConnection();
    }

@FXML public void InsereDuvidas(Duvidas d){
      String sql = "INSERT INTO duvidas" + "(email_duvida, nome_duvida, telefone_duvida, mensagem_duvida)"
                    + "VALUES(?,?,?,?);";

               try {
                   PreparedStatement p = c.prepareStatement(sql);
                   p.setString(1, d.getEmail_duvida());
                   p.setString(2, d.getNome_duvida());
                   p.setInt(3, d.getTelefone_duvida());
                   p.setString(4, d.getMensagem_duvida());
                   p.execute();
                   p.close();
        } catch (SQLException e) {
                   System.err.println("Erro ao Inserir DuvidasDAO" + e.getMessage());
        }
    }
  @FXML public ObservableList <Duvidas> getDuvidas(){
        try {
            ObservableList <Duvidas> f = FXCollections.observableArrayList(); 
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM duvidas");
            ResultSet rs = stmt.executeQuery();
         while(rs.next()){
             Duvidas p = new Duvidas();
             p.setEmail_duvida(rs.getString("email_duvida"));
             p.setNome_duvida(rs.getString("nome_duvida"));
             p.setTelefone_duvida(rs.getInt("telefone_duvida"));
             p.setMensagem_duvida(rs.getString("mensagem_duvida"));
             p.setId_duvida(rs.getInt("id_duvida"));
             f.add(p);
         }
         stmt.execute();
         rs.close();
         stmt.close();
         return f;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}