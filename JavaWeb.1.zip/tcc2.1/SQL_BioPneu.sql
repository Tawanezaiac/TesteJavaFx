﻿create table coleta(
id_col serial PRIMARY KEY,
local_col varchar (20),
horario_col int,
empresa_col varchar (10),
cidade_col varchar (20),
cep_col int,
endereco_col varchar (20),
data_col date
)
create table usuario(
id_usu serial PRIMARY KEY,
nome_usu varchar (70),
cpf_usu int,
email_usu varchar (100),
telefone_usu int,
sexo_usu varchar (10),
usuario_usu varchar (20),
senha_usu varchar (20),
nascimento_usu date
)
create table pneu(
id_pn serial PRIMARY KEY,
email_pn varchar (80),
bairro_pn varchar (50),
quantidade_pn int,
data_pn date,
obs_pn varchar(500),
local_pn varchar (200)
)

create table dicas(
id_d serial PRIMARY KEY,
email_d varchar(100),
nome_d varchar (50),
descricao_d varchar(200))


create table duvidas(
id_duvida serial Primary Key,
email_duvida varchar(100),
nome_duvida varchar (50),
telefone_duvida int,
mensagem_duvida varchar (500))


insert into dicas values (1, 'ola@ola.com', 'teste', 'ola osfsdggsfg')
drop table coleta
drop table usuario
drop table pneu
drop table dicas


select *from coleta
select *from usuario
select *from pneu
select *from dicas
select *from duvidas
