
package DAO;

import JDBC.CN;
import Model.Coleta;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;


public class ColetaDAO {
    public static Connection c;
    public ColetaDAO() throws ClassNotFoundException{
        ColetaDAO.c = CN.getConnection();
    }
 @FXML   public void insereColeta( Coleta col){
        String sql = "INSERT INTO coleta" + "(local_col, horario_col, empresa_col, cidade_col, cep_col, endereco_col, data_col)"
                    + "VALUES(?,?,?,?,?,?,?);";
        
                
                try {
             PreparedStatement p = c.prepareStatement(sql);
             p.setString(1, col.getLocal_col());
             p.setString(2, col.getHorario_col());
             p.setString(3,col.getEmpresa_col());
             p.setString(4,col.getCidade_col());
             p.setInt(5,col.getCep_col());
             p.setString(6, col.getEndereco_col());
             p.setDate(7, col.getData_col());
             p.execute();
             p.close();
        } catch (SQLException e) {
                    System.err.println(" Erro Insere ColetaDAO: " + e.getMessage());
        }
}
    
    @FXML   public ObservableList<Coleta> getColeta(){
        try{
            ObservableList<Coleta> funcs = FXCollections.observableArrayList();
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM coleta");
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Coleta func = new Coleta();
                func.setLocal_col(rs.getString("local_col"));
                Date datadia = rs.getDate("data_col");
                func.setData_col(datadia);
                func.setCep_col(rs.getInt("cep_col"));
                func.setHorario_col(rs.getString("horario_col"));
                func.setEndereco_col(rs.getString("endereco_col"));
                func.setEmpresa_col(rs.getString("empresa_col")); 
                func.setCidade_col(rs.getString("cidade_col"));
                func.setId_col(rs.getInt("id_col")); 
                funcs.add(func);
            }
            stmt.execute();
            rs.close();
            stmt.close();
            return funcs;
            }catch(SQLException e){
                throw new RuntimeException(e);
        }
    }
           public void deletaColeta(Coleta col){
       String sql = "DELETE FROM coleta WHERE id_col  =?";
        try{
           PreparedStatement stmt = c.prepareStatement(sql);
           stmt.setInt(1, col.getId_col());
           stmt.execute();
           stmt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
        
   }
}
