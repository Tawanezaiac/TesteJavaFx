
package DAO;

import JDBC.CN;
import Model.Usuario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

public class UsuarioDAO {
    public static Connection c;
    public UsuarioDAO() throws ClassNotFoundException{
        UsuarioDAO.c = CN.getConnection();
    }
 @FXML   public void insereUsuario(Usuario usu){
        String sql = "INSERT INTO usuario" + "(nome_usu, cpf_usu, email_usu, telefone_usu, sexo_usu, usuario_usu, senha_usu)"
                    + "VALUES(?,?,?,?,?,?,?);";
        
              Date data = Date.valueOf(usu.getNascimento_usu());
               
                try {
             PreparedStatement p = c.prepareStatement(sql);
             p.setString(1, usu.getNome_usu());
             p.setInt(2, usu.getCpf_usu());
             p.setString(3,usu.getEmail_usu());
             p.setInt(4,usu.getTelefone_usu());
             p.setString(5,usu.getSexo_usu());
             p.setString(6, usu.getUsuario_usu());
             p.setString(7, usu.getSenha_usu());
            p.setDate(8, Date.valueOf(usu.getNascimento_usu()));
             p.execute();
             p.close();
        } catch (SQLException e) {
                    System.out.println(" Erro Usuario Insere DAO: " + e.getMessage());
        }
}
       public ObservableList<Usuario> getUsuario(){
        try{
            ObservableList<Usuario> funcs = FXCollections.observableArrayList();
            PreparedStatement stmt = this.c.prepareStatement("SELECT * FROM usuario");
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Usuario func = new Usuario();
                func.setNome_usu(rs.getString("nome_usu"));
                Date datadia = rs.getDate("nascimento_usu");
                func.setNascimento_usu(datadia.toLocalDate());
                func.setCpf_usu(rs.getInt("cpf_usu"));
                func.setEmail_usu(rs.getString("email_usu"));
                func.setTelefone_usu(rs.getInt("telefone_usu"));
                func.setSexo_usu(rs.getString("sexo_usu")); 
                func.setUsuario_usu(rs.getString("usuario_usu"));
                func.setSenha_usu(rs.getString("senha_usu"));
                func.setId_usu(rs.getInt("id_usu")); 
                funcs.add(func);
            }
            stmt.executeQuery();
            rs.close();
            stmt.close();
            return funcs;
            }catch(SQLException e){
               System.out.println(" Erro Usuario Select DAO: " + e.getMessage());
        }
        return null;
    }
        public void atualizaUsuario(Usuario us){
    String sql = "UPDATE usuario SET nome_usu=?, email_usu=?, telefone_usu=?, sexo_usu=?, usuario_usu=?, senha_usu=? WHERE cpf_usu=?";
    PreparedStatement stmt ;
    try{
             PreparedStatement p = c.prepareStatement(sql);
             p.setString(1, us.getNome_usu());
             p.setInt(2, us.getCpf_usu());
             p.setString(3,us.getEmail_usu());
             p.setInt(4,us.getTelefone_usu());
             p.setString(5,us.getSexo_usu());
             p.setString(6, us.getUsuario_usu());
             p.setString(7, us.getSenha_usu());
//             p.setDate(8, Date.valueOf(us.getNascimento_usu()));
             p.execute();
             p.close();
             p.execute(); 
             p.close();
        }catch(SQLException e){
            System.out.println("Deu Erro UserDAO: "+e.getMessage());
        }
    }
       public void deleta_funcionario(Usuario func){
       String sql = "DELETE FROM usuario WHERE id_usu  =?";
        try{
           PreparedStatement stmt = c.prepareStatement(sql);
           stmt.setInt(1, func.getId_usu());
           stmt.execute();
           stmt.close();
       
        }catch (SQLException e) {
            e.printStackTrace(); 
        }
        
   }
}
