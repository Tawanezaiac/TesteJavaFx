
package Model;

import java.sql.Date;
import java.time.LocalDate;

public class Coleta {
    private int id_col;
    private String local_col;
    private String horario_col;
    private String empresa_col;
    private String cidade_col;
    private int cep_col;
    private String endereco_col;
    private Date data_col;
   
   public Coleta(){
       
   } 

    public Coleta(int id_col, String local_col, String horario_col, String empresa_col, String cidade_col, int cep_col, String endereco_col, Date data_col) {
        this.id_col = id_col;
        this.local_col = local_col;
        this.horario_col = horario_col;
        this.empresa_col = empresa_col;
        this.cidade_col = cidade_col;
        this.cep_col = cep_col;
        this.endereco_col = endereco_col;
        this.data_col = data_col;
    }
    @Override
    public String toString() {
        return "Coleta:"+"\n"+
                " local=" + local_col + "\n"+
                " horario=" + horario_col + "\n"+
                " empresa=" + empresa_col + "\n"+
                " cidade=" + cidade_col + "\n"+
                " cep=" + cep_col + "\n"+
                " endereço=" + endereco_col + "\n"+
                " data=" + data_col + "\n"+
                "\n";
    }

    public int getId_col() {
        return id_col;
    }

    public void setId_col(int id_col) {
        this.id_col = id_col;
    }

    public String getLocal_col() {
        return local_col;
    }

    public void setLocal_col(String local_col) {
        this.local_col = local_col;
    }

    public String getHorario_col() {
        return horario_col;
    }

    public void setHorario_col(String horario_col) {
        this.horario_col = horario_col;
    }

    public String getEmpresa_col() {
        return empresa_col;
    }

    public void setEmpresa_col(String empresa_col) {
        this.empresa_col = empresa_col;
    }

    public String getCidade_col() {
        return cidade_col;
    }

    public void setCidade_col(String cidade_col) {
        this.cidade_col = cidade_col;
    }

    public int getCep_col() {
        return cep_col;
    }

    public void setCep_col(int cep_col) {
        this.cep_col = cep_col;
    }

    public String getEndereco_col() {
        return endereco_col;
    }

    public void setEndereco_col(String endereco_col) {
        this.endereco_col = endereco_col;
    }

    public Date getData_col() {
        return data_col;
    }

    public void setData_col(Date data_col) {
        this.data_col = data_col;
    }
}
