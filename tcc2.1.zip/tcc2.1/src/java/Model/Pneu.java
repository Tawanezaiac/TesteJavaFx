
package Model;

import java.sql.Date;
import java.time.LocalDate;

public class Pneu {
    private int id_pn;
    private String email_pn;
    private String obs_pn;
    private String bairro_pn;
    private int quantidade_pn;
    private String local_pn;
    private Date data_pn;

   
   public Pneu(){
       
   } 

    public Pneu(int id_pn, String email_pn, String obs_pn, String bairro_pn, int quantidade_pn, String local_pn, Date data_pn) {
        this.id_pn = id_pn;
        this.email_pn = email_pn;
        this.obs_pn = obs_pn;
        this.bairro_pn = bairro_pn;
        this.quantidade_pn = quantidade_pn;
        this.local_pn = local_pn;
        this.data_pn = data_pn;
    }
 
                 @Override
    public String toString(){
         return "Dicas:" + "\n"+
                " email=" + email_pn + "\n"+
                " obs=" + obs_pn + "\n"+
                " bairro=" + bairro_pn + "\n"+
                " quantidade=" + quantidade_pn + "\n"+
                " local=" + local_pn + "\n"+
                " data=" + data_pn + "\n"+
                "\n";
    }

    /**
     * @return the id_pn
     */
    public int getId_pn() {
        return id_pn;
    }

    /**
     * @param id_pn the id_pn to set
     */
    public void setId_pn(int id_pn) {
        this.id_pn = id_pn;
    }

    /**
     * @return the email_pn
     */
    public String getEmail_pn() {
        return email_pn;
    }

    /**
     * @param email_pn the email_pn to set
     */
    public void setEmail_pn(String email_pn) {
        this.email_pn = email_pn;
    }

    /**
     * @return the obs_pn
     */
    public String getObs_pn() {
        return obs_pn;
    }

    /**
     * @param obs_pn the obs_pn to set
     */
    public void setObs_pn(String obs_pn) {
        this.obs_pn = obs_pn;
    }

    /**
     * @return the bairro_pn
     */
    public String getBairro_pn() {
        return bairro_pn;
    }

    /**
     * @param bairro_pn the bairro_pn to set
     */
    public void setBairro_pn(String bairro_pn) {
        this.bairro_pn = bairro_pn;
    }

    /**
     * @return the quantidade_pn
     */
    public int getQuantidade_pn() {
        return quantidade_pn;
    }

    /**
     * @param quantidade_pn the quantidade_pn to set
     */
    public void setQuantidade_pn(int quantidade_pn) {
        this.quantidade_pn = quantidade_pn;
    }

    /**
     * @return the local_pn
     */
    public String getLocal_pn() {
        return local_pn;
    }

    /**
     * @param local_pn the local_pn to set
     */
    public void setLocal_pn(String local_pn) {
        this.local_pn = local_pn;
    }

    /**
     * @return the data_pn
     */
    public Date getData_pn() {
        return data_pn;
    }

    /**
     * @param data_pn the data_pn to set
     */
    public void setData_pn(Date data_pn) {
        this.data_pn = data_pn;
    }
}
