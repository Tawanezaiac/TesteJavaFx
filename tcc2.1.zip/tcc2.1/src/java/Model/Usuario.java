
package Model;
import java.time.LocalDate;

public class Usuario {
    private int id_usu;
    private String nome_usu;
    private int cpf_usu;
    private String email_usu;
    private int telefone_usu;
    private String sexo_usu;
    private String usuario_usu;
    private String senha_usu;
    private LocalDate nascimento_usu;
   
   public Usuario(){
       
   } 

    public Usuario(int id_usu, String nome_usu, int cpf_usu, String email_usu, int telefone_usu, String sexo_usu, String usuario_usu, String senha_usu, LocalDate nascimento_usu) {
        this.id_usu = id_usu;
        this.nome_usu = nome_usu;
        this.cpf_usu = cpf_usu;
        this.email_usu = email_usu;
        this.telefone_usu = telefone_usu;
        this.sexo_usu = sexo_usu;
        this.usuario_usu = usuario_usu;
        this.senha_usu = senha_usu;
        this.nascimento_usu = nascimento_usu;
    }
 
   
                 @Override
    public String toString() {
         return "Dicas:  " + "\n"+
                " nome=" + nome_usu + "\n"+
                " cpf=" + cpf_usu + "\n"+
                " email=" + email_usu + "\n"+
                " telefone-=" + telefone_usu + "\n"+
                " sexo-=" + sexo_usu + "\n"+
                " usuario-=" + usuario_usu + "\n"+
                " nascimento=" + nascimento_usu + "\n"+
                "\n";}
    /**
     * @return the id_usu
     */
    public int getId_usu() {
        return id_usu;
    }

    /**
     * @param id_usu the id_usu to set
     */
    public void setId_usu(int id_usu) {
        this.id_usu = id_usu;
    }

    /**
     * @return the nome_usu
     */
    public String getNome_usu() {
        return nome_usu;
    }

    /**
     * @param nome_usu the nome_usu to set
     */
    public void setNome_usu(String nome_usu) {
        this.nome_usu = nome_usu;
    }

    /**
     * @return the cpf_usu
     */
    public int getCpf_usu() {
        return cpf_usu;
    }

    /**
     * @param cpf_usu the cpf_usu to set
     */
    public void setCpf_usu(int cpf_usu) {
        this.cpf_usu = cpf_usu;
    }

    /**
     * @return the email_usu
     */
    public String getEmail_usu() {
        return email_usu;
    }

    /**
     * @param email_usu the email_usu to set
     */
    public void setEmail_usu(String email_usu) {
        this.email_usu = email_usu;
    }

    /**
     * @return the telefone_usu
     */
    public int getTelefone_usu() {
        return telefone_usu;
    }

    /**
     * @param telefone_usu the telefone_usu to set
     */
    public void setTelefone_usu(int telefone_usu) {
        this.telefone_usu = telefone_usu;
    }

    /**
     * @return the sexo_usu
     */
    public String getSexo_usu() {
        return sexo_usu;
    }

    /**
     * @param sexo_usu the sexo_usu to set
     */
    public void setSexo_usu(String sexo_usu) {
        this.sexo_usu = sexo_usu;
    }

    /**
     * @return the usuario_usu
     */
    public String getUsuario_usu() {
        return usuario_usu;
    }

    /**
     * @param usuario_usu the usuario_usu to set
     */
    public void setUsuario_usu(String usuario_usu) {
        this.usuario_usu = usuario_usu;
    }

    /**
     * @return the senha_usu
     */
    public String getSenha_usu() {
        return senha_usu;
    }

    /**
     * @param senha_usu the senha_usu to set
     */
    public void setSenha_usu(String senha_usu) {
        this.senha_usu = senha_usu;
    }

    /**
     * @return the nascimento_usu
     */
    public LocalDate getNascimento_usu() {
        return nascimento_usu;
    }

    /**
     * @param nascimento_usu the nascimento_usu to set
     */
    public void setNascimento_usu(LocalDate nascimento_usu) {
        this.nascimento_usu = nascimento_usu;
    }
}
